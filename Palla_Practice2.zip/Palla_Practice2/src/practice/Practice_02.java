package practice;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Practice_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 { Queue<Integer> queue = new LinkedList<>();
		 Stack<Integer> stack = new Stack<Integer>();
		 for (int i = 0; i < 10; i++) { queue.add(i);
		 } System.out.println("Queue :" + queue);
		 while(!queue.isEmpty()) { stack.add(queue.poll());
		 } System.out.println("Queue :" + queue); System.out.println("Stack :" + stack); } }
	}


