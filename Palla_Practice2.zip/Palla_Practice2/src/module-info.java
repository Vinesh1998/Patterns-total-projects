/**
 * 
 */
/**
 * @author s549130
 *
 */
module Palla_Practice2 {
}