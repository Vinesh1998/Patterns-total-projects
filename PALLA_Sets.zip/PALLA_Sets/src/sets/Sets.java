package sets;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Sets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 
		 Set<Integer> num01 = new HashSet<>();
	     num01.add(50);
		 num01.add(60);
		 num01.add(30);
		 num01.add(45);
		 num01.add(90);
		 int max = getMax(num01);
		 System.out.println("Maximum value in the set is: " + max);
		 }
	 public static int getMax(Set<Integer> set)
	 {
		 if (set == null || set.isEmpty()) 
		 {
			 throw new IllegalArgumentException("Set cannot be null or empty.");
			 }
		 int max = Integer.MIN_VALUE;
		 for (int num : set) {
			 if (num > max)
			 {
				 max = num;
				 }
			 }
		 return max;
		 }
		}
		

	


