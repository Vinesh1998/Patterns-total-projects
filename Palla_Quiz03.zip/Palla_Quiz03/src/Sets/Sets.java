package Sets;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

public class Sets {

		// TODO Auto-generated method stub
		 public static int maxSet(Set s)
		 { 
			 int max =0;
			 Iterator it = s.iterator();
		 while(it.hasNext()) 
		 { 
			 Integer ele = (Integer)it.next();
			 if(ele>max) {
				 max = ele;
			 }
			 }
		 return max;
		 }
		 public static int minSet(Set s)
		 {
			 int min =0; Integer[] arr = new Integer[s.size()];
			 s.toArray(arr);
			 Arrays.sort(arr);
			 min = arr[0];
			 return min;
			 }
		 public static void main(String[] args)
		 {
				 Set<Integer> j = new HashSet<>();
				 Random r = new Random();
			 for(int i=0;i<10;i++) {
				 j.add(r.nextInt(18, 40));
				 }
			 System.out.println(j); 
			 System.out.println("The maximum element is : " + maxSet(j));
			 System.out.println("The minimum element is : " + minSet(j));
			 

	}

}
