/**
 * 
 */
/**
 * @author s549130
 *
 */
module Palla_Assignment2 {
}