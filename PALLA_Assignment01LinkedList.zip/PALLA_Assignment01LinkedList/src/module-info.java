/**
 * 
 */
/**
 * @author s549130
 *
 */
module Lastname_Assignment01LinkedList {
}