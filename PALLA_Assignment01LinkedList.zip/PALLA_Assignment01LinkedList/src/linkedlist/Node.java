package linkedlist;

public class Node {
	int data;
	Node next;
	Node prev;
	
	public Node(int num) {
		data = num;
		next = null;
		prev = null;
	}
}

